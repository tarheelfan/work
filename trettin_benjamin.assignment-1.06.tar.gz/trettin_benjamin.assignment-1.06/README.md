Assignment 1.06 - Fog of War and Porting to c++

SETUP

Run 'make' inside the trettin_benjamin.assignment-1.06 directory to build the project. --You can also run 'make Clean' to clean the repo--

Running Source Code

The dungeon game can only be run using the ./run command with the --nummon switch. The switch includes a value for the number of monsters to be generated.

EXAMPLE: ./run --nummon 10

The source code is located inside of the map.c, heap.c, monster.c, pcio.c and main.c files.

Notes

The CHANGELOG file shows all of my commits for this project up to this point.
