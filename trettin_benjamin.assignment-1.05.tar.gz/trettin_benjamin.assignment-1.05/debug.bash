gdb --args ./run 
