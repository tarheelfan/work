rm run
rm gameMap.a
rm map.o
rm heap.o
rm heap.a
rm monster.o
rm pcio.o