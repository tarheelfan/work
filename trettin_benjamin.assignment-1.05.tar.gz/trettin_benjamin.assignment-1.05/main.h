int initGame(void);
void StartGame(void);
void closeGame(void);