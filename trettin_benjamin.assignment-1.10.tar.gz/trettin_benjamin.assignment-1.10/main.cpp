#include <iostream>
#include <cstdlib>
#include "calculatePi.cpp"
#include "sumOfPrimes.cpp"
int main(int argc, char* argv[]){
	if(!argv[1]){
		std::cout << "Please include the number of primes you wish to sum in your run" << std::endl;
	}
	else{
		std::cout << "A list of the first " << argv[1] << " prime numbers:" << std::endl;
		int numOfPrimes = atoi(argv[1]);

		//Find and Print the summotion of the first n primes
		sumPrimes(numOfPrimes);

		//Calculating Pi
  	PiClass pi(1);
  	pi.calculate();
	}
}
