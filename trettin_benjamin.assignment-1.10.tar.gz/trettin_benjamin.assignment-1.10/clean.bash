rm calculatePi.o
rm sumOfPrimes.o
rm run
