#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream>
using namespace std;
class PiClass
{
    int d;
    double pi;
    double extraction(int);
    long modular(int, int, int);

public:
    PiClass(int);
    void calculate();
};

PiClass::PiClass(int d)
{
    this->d = d - 1;
}


void PiClass::calculate()
{
    pi = (4*extraction(1)) - (2*extraction(4)) - extraction(5) - extraction(6);
    pi = pi - (int)pi + 4.0;
    printf("PI =  %.15f\n" , pi);
}

double PiClass::extraction(int value){
  double prefix = 1.0e-17;
  double a = 0.0;
  double b;
  int    c;
  int    e;

  for (e=0; e<=d; e++) {
      c = (8*e) + value;
      b = (double)modular(16, d - e, c);
      b /= c;
      a += b - (int)b;
      a -= (int)a;
  }
  while (1) {
      c = 8 * e + value;
      b = pow(16.0, (double)(d - e));
      b /= (double)c;
      if (b < prefix) break;
      a += b;
      a -= (int)a;
      e ++;
  }

  return a;
}
long PiClass::modular(int length, int diff, int c){
    long result;
    if(diff==0){
      return 1;
    }
    result = modular(length, diff / 2, c);
    result = (result*result) % c;
    if( (diff % 2) == 1 ){
      result = (result*length) % c;
    }
    return result;
}
