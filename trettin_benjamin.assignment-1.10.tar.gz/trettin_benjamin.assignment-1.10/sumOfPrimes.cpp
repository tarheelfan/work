#include <cstdlib>
#include <iostream>

bool isPrime(unsigned int value);
void sumPrimes(int totalPrimes);

void sumPrimes(int totalPrimes){
	int a = 1;
	int b = 0;
	int total = 0;
	while(b < totalPrimes){
			if(isPrime(a)){
				total = total + a;
				b++;
				std::cout << a << std::endl;
			}
			a++;
		}
	std::cout << "The sum of the first " << totalPrimes << " prime numbers = " << total << std::endl;
	}
bool isPrime(unsigned int value){
	if (value <= 1){
		return false;
	}
    unsigned int a;
    for (a=2; a*a<=value; a++){
        if (value % a == 0){
						return false;
				}
    }
    return true;
}
