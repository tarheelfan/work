Assignment 1.09 - PC Equipment and Update Combat


SETUP

Run 'make' inside the trettin_benjamin.assignment-1.09 directory to build the project. --You can also run 'make Clean' to clean the repo--

Running Source Code

The dungeon game can only be run using the ./run command with the --nummon switch. The switch includes a value for the number of monsters to be generated.

EXAMPLE: ./run --nummon 10

IMPORTANT: For a game to start, press any game key twice for a player to appear.

Notes

The CHANGELOG file shows all of my commits for this project up to this point.
