Assignment 1.07 - Parsing Monster Definitions


SETUP

Run 'make' inside the trettin_benjamin.assignment-1.07 directory to build the project. --You can also run 'make Clean' to clean the repo--

Running Source Code

This program for this HW has the game functionality commented out. All that remains functional is the parsing of the file. After parsing it creates
a npcInfo object and uses a built in function to print the data from inside the object to prove that the correct data is being parsed and processed.

Notes

The CHANGELOG file shows all of my commits for this project up to this point.
