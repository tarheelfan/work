rm run
rm gameMap.a
rm map.o
rm heap.o
rm heap.a
rm monster.o
rm pcio.o
rm mons.o
rm mon.o
rm knowledgeMap.o
rm npcParser.o
rm objectParser.o
rm monsterFactory.o
rm dice.o
reset
